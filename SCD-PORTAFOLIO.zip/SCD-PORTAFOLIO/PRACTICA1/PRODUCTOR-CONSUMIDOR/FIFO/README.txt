Implementación: FIFO
Variables compartidas: ninguna 
Semáforos utilizados:

SEMÁFOROS DE SINCRONIZACIÓN: aseguran que solo haya lecturas cuando haya algún dato escrito en el buffer y que no se escriba cuando este esté lleno.

	puede_leer: inicializado a 0. La función del consumidor tiene un sem_wait a este semáforo al principio para que no lea hasta que exista al menos un dato en el buffer. Cada vez que la funcion_productor escribe un dato en el buffer manda un sem_post para que se pueda leer algún dato. 

	puede_escribir: inicializado a tam_vector. La función del productor llama al sem_Wait de este semáforo al principio del bucle para asegurarse de que puede escribir (buffer no lleno). La función consumidor envia el sem_post cada vez que lee un dato para indicar que se ha liberado un espacio en el buffer.

(El valor de ambos semáforos puede variar entre 0 y tam_vector, ya que técnicamente cada vez que el productor hace un sem_post a puede_leer tiene que haber hecho antes un sem_wait a puede_escribir; es decir, cada vez que aumenta puede_leer, disminuye puede escribir, y al revés).
	

-----------------------------------
SEMÁFOROS PARA CONTROLAR LA EXCLUSIÓN MÚTUA.

	mutex_libre: inicializado a 1. Ocurre igual que con el anterior, asegura la exclusión mútua del productor y el consumidor en el acceso a "primera_libre", la variable compartida que controla la posición de lectura/escritura del buffer.




