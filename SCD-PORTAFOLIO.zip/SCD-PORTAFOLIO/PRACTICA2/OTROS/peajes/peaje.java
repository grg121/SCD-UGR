import monitor.* ;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.lang.*;

class aux{
    static Random genAlea = new Random() ;
    static void dormir_max( int milisecsMax ){
	try{
	    Thread.sleep( genAlea.nextInt( milisecsMax ) ) ;
        }
	catch( InterruptedException e ){
	    System.err.println("sleep interumpido en ’aux.dormir_max()’");
	}
    }
}


class Peaje extends AbstractMonitor{
    
    private Condition [] cabinas = new Condition[2] ;

    public boolean [] ocupada = new boolean[2] ; 
    

    public Peaje(){
	for(int i = 0 ; i < 2 ; i++){
	    cabinas[i] = makeCondition() ;
            ocupada[i] = false ;
	}
    }

    public int llegada_peaje(){
	enter() ;

	int salida = 0 ;

	if(ocupada[0] && !ocupada[1])
	    salida = 1 ;
	else if(ocupada[1] && ocupada[0]){
	    if(cabinas[0].count() > cabinas[1].count())
		salida = 1 ;
	    cabinas[salida].await() ;
	}

	ocupada[salida] = true ; 
 	
	leave() ;
	
	return salida ;
    }

    public void pagado( int cab ){
	enter() ;

	ocupada[cab] = false ;
	cabinas[cab].signal() ; 
	
	leave() ;
    }
}


class Coche implements Runnable{

    public int cabina;
    public Thread thr ;
    public Peaje peaje = new Peaje() ;



    public Coche (Peaje peaje, String nombre) {
	this.cabina = 0 ; 
	this.peaje = peaje ; 
	thr = new Thread(this, nombre) ;
    }

    public void run(){
	while( true ){

	    System.out.println(thr.getName() + " llega al peaje") ; 

	    cabina = peaje.llegada_peaje() ;
       
	    System.out.println("\t"+thr.getName() + " ocupa la cabina " + Integer.toString(cabina) ) ;
	    aux.dormir_max( 9011 ) ;
	    System.out.println("\t"+thr.getName() + " libera la cabina " +  Integer.toString(cabina) ) ;

	    peaje.pagado(cabina) ; 
	    
	}
    }
}

class Peajes{ 

    
    public static void main(String[] args){
	if( args.length != 1){
	    System.err.println("Número incorrecto de agumentos. Debes pasar el número de coches.") ;
	    return ;
	}
	Peaje peaje = new Peaje() ;
	int ncoches = Integer.parseInt(args[0]) ; 
	Coche [] coches = new Coche [ncoches] ; 

        int i = 0 ; 

	for(Coche coche : coches ){
	    coche = new Coche(peaje,"Coche " + Integer.toString(i));
	    coche.thr.start() ;
	    i++ ;
	}
	}
    }


			      
