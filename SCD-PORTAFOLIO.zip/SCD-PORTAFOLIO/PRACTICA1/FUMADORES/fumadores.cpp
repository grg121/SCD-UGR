// *****************************************************************************
//
// Prácticas de SCD. Práctica 1.
// Plantilla de código para el ejercicio de los fumadores
//
// *****************************************************************************

#include <iostream>
#include <cassert>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>      // incluye "time(....)"
#include <unistd.h>    // incluye "usleep(...)"
#include <stdlib.h>    // incluye "rand(...)" y "srand"

using namespace std ;


const int NFUMADORES = 3;
sem_t s_ingrediente[NFUMADORES] ;
sem_t s_estanquero ;
sem_t s_cout ;

/* s_ingrediente[1] == necesita papel
   s_ingrediente[2] == necesita tabaco
   s_ingrediente[3] == necesita cerillas
*/

string * INGREDIENTE ;



// ---------------------------------------------------------------------
// introduce un retraso aleatorio de duración comprendida entre
// 'smin' y 'smax' (dados en segundos)

void retraso_aleatorio( const float smin, const float smax )
{
  static bool primera = true ;
  if ( primera )        // si es la primera vez:
  {  srand(time(NULL)); //   inicializar la semilla del generador
     primera = false ;  //   no repetir la inicialización
  }
  // calcular un número de segundos aleatorio, entre {\ttbf smin} y {\ttbf smax}
  const float tsec = smin+(smax-smin)*((float)random()/(float)RAND_MAX);
  // dormir la hebra (los segundos se pasan a microsegundos, multiplicándos por 1 millón)
  usleep( (useconds_t) (tsec*1000000.0)  );
}

// ----------------------------------------------------------------------------
// función que simula la acción de fumar, como un retardo aleatorio de la hebra.
// recibe como parámetro el numero de fumador
// el tiempo que tarda en fumar está entre dos y ocho décimas de segundo.

void fumar( int num_fumador )
{  sem_wait( &s_cout) ;
   cout << "Fumador número " << num_fumador+1 << ": comienza a fumar." << endl << flush ;
   sem_post( &s_cout) ;
   retraso_aleatorio( 0.2, 0.8 );
   sem_wait( &s_cout);
   cout << "Fumador número " << num_fumador+1 << ": termina de fumar." << endl << flush ;
   sem_post( &s_cout) ;
}

void * fun_fumador(void * fumador_ID){
  unsigned long nfum = (unsigned long) fumador_ID ;
  while(true){
    sem_wait(&s_cout) ;
    cout << "Fumador número " << nfum+1 << ": espera " << INGREDIENTE[nfum] << endl << flush ;
    sem_post(&s_cout) ;
    sem_wait( &(s_ingrediente[nfum]) ) ;
    sem_wait(&s_cout);
    cout << "Fumador número " << nfum+1 <<": recibe " << INGREDIENTE[nfum] << endl << flush ;
    sem_post(&s_cout) ; 
    sem_post( &s_estanquero ) ;

    fumar(nfum) ;
  } return NULL ;
}

void * fun_estanquero(void *){
  srand(time(NULL)) ;
  while(true){
    sem_wait( &s_estanquero ) ;
    // A continuación produce el ingrediente necesario para "liberar" al fumador número...
    int ingrediente = random()%3 ;
    sem_wait( &s_cout) ;
    cout << "Estanquero produce: " << INGREDIENTE[ingrediente] << endl << flush ;
    sem_post( &s_cout) ;
    sem_post( &(s_ingrediente[ingrediente]) ) ;
  }
  return NULL ;
}



int main()
{
  sem_init( &s_cout, 0, 1) ;
  sem_init( &s_estanquero, 0, 1) ;


  INGREDIENTE = new string[3] ;
    INGREDIENTE[0] = "papel" ;
    INGREDIENTE[1] = "tabaco" ;
    INGREDIENTE[2] = "cerillas";

  pthread_t id_fumador[NFUMADORES] ;
  pthread_t estanquero ;



  for( unsigned long i = 0 ; i < NFUMADORES ; i++ ){
    sem_init( &(s_ingrediente[i]), 0, 0) ;
    pthread_create( &(id_fumador[i]),NULL,fun_fumador,(void *) i ) ;
  }

  pthread_create(&estanquero, NULL, fun_estanquero, NULL) ;

  pthread_exit(NULL) ; 
}
