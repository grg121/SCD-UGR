import monitor.* ;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;


class aux{
    static Random genAlea = new Random() ;
    static void dormir_max( int milisecsMax ){
	try{
	    Thread.sleep( genAlea.nextInt( milisecsMax ) ) ;
        }
	catch( InterruptedException e ){
	    System.err.println("sleep interumpido en ’aux.dormir_max()’");
	}
    }
}


class Barberia extends AbstractMonitor{

    Condition barbero = makeCondition() ; 
    Condition cliente_corte = makeCondition() ;
    Condition cliente_espera = makeCondition() ;

    boolean puede_dormir = true ;
    boolean cortando = false ;
    int cortes_seguidos = 0 ;
    final int num_sillas = 5  ; 
    
    // invocado por los clientes para cortarse el pelo
    public void cortarPelo(String nombre){
	enter() ;

	if( cliente_espera.count() < num_sillas){
	puede_dormir = false ;
	System.out.println( nombre + " llega a la barberia. ") ;

    	if(cortando){
		System.out.println( nombre + " aguarda en la sala de espera. " ) ; 
		cliente_espera.await() ;    // entra a la sala de espera
	}else if (!barbero.isEmpty()){
		System.out.println( nombre + " llama al barbero. ") ; 
		barbero.signal() ;  // si el barbero duerme, lo despierta
	}

	System.out.println( nombre + " está cortándose el pelo") ;
	cortando = true ;  
	cliente_corte.await() ;    // espera durante el cliente_corte


	if(cliente_espera.isEmpty())
	    puede_dormir = true ;

	}
	else{
	    System.out.println("La sala de espera está llena: " + nombre + " se marcha.") ;
	}
	leave() ;

    }

    // invocado por el barbero para esperar (si procede) a un nuevo cliente y sentarlo para el cliente_corte
    public void siguienteCliente(){
	enter() ;
	
	if(puede_dormir){ 
	    System.out.println("Barbero duerme.") ; 
	    barbero.await() ;
	    System.out.println("Barbero despierta.") ;
	    cortes_seguidos = 0 ;  
	}else if(cliente_corte.isEmpty()){
		System.out.println("Barbero llama a un cliente.") ;
		cliente_espera.signal() ;
	}

	System.out.println( "\tBarbero comienza a cortar el pelo." ) ; 

	// termina el método y pasa a cortar el pelo. 
 	
	leave() ;
    }

    // invocado por el barbero para indicar que ha terminado de cortar el pelo
    public void finCliente(){
	enter() ;

	System.out.println("\tBarbero termina de cortar el pelo." ) ; 	
	cortes_seguidos += 1 ; 
	cliente_corte.signal() ;
	cortando = false ;
	if(cortes_seguidos == 3)
	    System.out.println("Estoy harto de pelar a esta panda de melenudos piojosos.") ;
	
	leave() ;
    }

}

class Cliente implements Runnable{
    public Thread thr ;
    private Barberia barberia ;

    public Cliente(Barberia laBarberia, String nombre){
	barberia = laBarberia ;
	thr = new Thread(this, nombre) ;
    }

    public void run(){
	while(true){
	    barberia.cortarPelo(thr.getName()) ;
	    System.out.println( thr.getName() + " sale de la barberia. ") ; 
	    aux.dormir_max( 55500 ) ;
	}
    }
}

class elBarbero implements Runnable{
    public Thread thr ;
    private Barberia barberia ;

    public elBarbero(Barberia laBarberia, String nombre){
	barberia = laBarberia ;
	thr = new Thread(this, nombre) ;

    }
    
    public void run(){
	while (true) {
	    barberia.siguienteCliente() ;
	    aux.dormir_max( 5500 ) ; // MIENTRAS CORTA EL PELO
	    barberia.finCliente() ;

	}
    }
}
    class Barbero{
	public static void main(String [] args){
	    if ( args.length != 1 ){
		System.err.println("Uso: <número de clientes> " ) ;
		return ;
	    }

	    Cliente[] clientes = new Cliente[Integer.parseInt(args[0])] ;

	    Barberia barberia = new Barberia() ;

	    elBarbero barbero = new elBarbero(barberia, "barbero") ;

	    
	    for(int i = 0 ; i < clientes.length ; i++)
		clientes[i] = new Cliente(barberia, "Cliente" + (i+1)) ;
 
	    barbero.thr.start();

	    for(int i = 0 ; i < clientes.length ; i++)
		clientes[i].thr.start() ; 


	}
    }
      
