import monitor.* ;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

class aux{
    static Random genAlea = new Random() ;
    static void dormir_max( int milisecsMax ){
	try{
	    Thread.sleep( genAlea.nextInt( milisecsMax ) ) ;
        }
	catch( InterruptedException e ){
	    System.err.println("sleep interumpido en ’aux.dormir_max()’");
	}
    }
}


class Estanco extends AbstractMonitor{
    
    private Condition estanquero = makeCondition() ;

    private Condition [] ingredientes = new Condition[3] ;

    
    public ArrayList<String> ingredientes_string =  
      	new ArrayList<String>(Arrays.asList("papel", "tabaco", "cerillas"));

    
    int ingrediente = -1  ;  
    // 0 --> papel
    // 1 --> tabaco
    // 2 --> cerillas
    // <0 --> vacío

    public Estanco(){
	for(int i = 0 ; i < 3 ; i++)
	    ingredientes[i] = makeCondition() ;
    }

    public void obtenerIngrediente( int miIngrediente ){
	enter() ;
	if(miIngrediente != ingrediente){
	System.out.println("fumador " +	 miIngrediente + " espera: "
		         + ingredientes_string.get(miIngrediente) ) ;
	   
	ingredientes[miIngrediente].await() ;
	}
	
        System.out.println("fumador " + miIngrediente + " recibe: "
			     + ingredientes_string.get(miIngrediente) ) ;
	ingrediente = -1 ; // mostrador vacío

	System.out.println("--- Mostrador libre ---") ; 

	estanquero.signal() ;
	
	leave() ; 
    }

    public void ponerIngrediente( int nuevo_ingrediente ){
	enter() ;
	if(ingrediente >= 0){
	    estanquero.await() ; //espera la retirada del ingrediente 
	} else {
	    System.out.println("Estanquero coloca " + ingredientes_string.get(nuevo_ingrediente)) ;
	    if(nuevo_ingrediente == ingrediente)
		System.out.println("Se ha puesto el mismo ingrediente que antes") ; 
	    ingrediente = nuevo_ingrediente ; 
	    ingredientes[ingrediente].signal() ;
	}
	leave() ; 

    }

    public void esperarRecogidaIngrediente(){
	enter();
	if(ingrediente >= 0){
	    estanquero.await() ;
	}
	leave() ; 
    }

}

class Fumador implements Runnable{

    public int miIngrediente ;
    public Thread thr ;
    public Estanco estanco = new Estanco() ;



    public Fumador(int p_miIngrediente, Estanco estanco, String nombre) {
	miIngrediente = p_miIngrediente ;
	this.estanco = estanco ;
	thr = new Thread(this, nombre) ;
    }

    public void run(){
	while( true ){
	   
	    estanco.obtenerIngrediente( miIngrediente ) ;
	    estanco.obtenerIngrediente( miIngrediente ) ; 
	    
	    System.out.println("fumador " + miIngrediente 
			       + " empieza a fumar" ) ;
	    
	    aux.dormir_max( 200 ) ;
	    System.out.println("fumador " + miIngrediente
			       + " termina de fumar" ) ;
	    
	}
    }
}

class Estanquero implements Runnable{
    public Thread thr ;
    public Estanco estanco ; 
    public Estanquero(Estanco estanco){
	this.estanco = estanco ;
	this.thr = new Thread(this, "estanquero") ; 
    }

    public void run(){
	int ingrediente ;
	while(true){
	    ingrediente = (int) (Math.random () * 3.0) ;
	    estanco.ponerIngrediente( ingrediente ) ;
	    estanco.esperarRecogidaIngrediente() ;
       
   
	}
    }
}

class Fumadores{

    
    public static void main(String[] args){
	Estanco estanco = new Estanco() ;
	
        Estanquero estanquero = new Estanquero(estanco) ;

	Fumador[] fumadores = new Fumador[3] ;

        int i = 0 ; 

	for(Fumador fumador : fumadores){
	    fumador = new Fumador(i,estanco,"fumador" + i) ;
	    fumador.thr.start() ;
	    i++ ; 
	}


	    

	estanquero.thr.start() ; 
    
     
}
}
