import monitor.* ;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

class aux{
    static Random genAlea = new Random() ;
    static void dormir_max( int milisecsMax ){
	try{
	    Thread.sleep( genAlea.nextInt( milisecsMax ) ) ;
        }
	catch( InterruptedException e ){
	    System.err.println("sleep interumpido en ’aux.dormir_max()’");
	}
    }
}



// ****************************************************************************

class Recurso extends AbstractMonitor
{  

    final int NUM_TIPOS = 2 ; 
    
    private int [] dentro = new int[NUM_TIPOS] ;

    private Condition [] espera = new Condition[NUM_TIPOS] ; 

    
  public Recurso()
  {
      for(int i = 0 ; i < NUM_TIPOS ; i++){
	  espera[i] = makeCondition() ;
	  dentro[i] = 0 ;
      }
  }

    
    public void acceso( int TH, String nombre )
  {
      enter() ;
      System.out.println(nombre + " intenta acceder al recurso. ") ; 
      if( TH + 2 == dentro[TH] ){
	  System.out.println(nombre + ": recurso ocupado -> espera. ") ; 
	  espera[TH].await() ;
      }
      System.out.println(nombre + " accede al recurso ") ; 
      dentro[TH]++ ;
    leave() ; 
  }
    public void fin_acceso( int TH, String nombre )
  {
    enter() ;
    System.out.println(nombre + " termina de utilizar el recurso " ) ; 
    dentro[TH]-- ; 
    espera[TH].signal() ; 
    leave() ; 
  }
}

// ****************************************************************************

class Hebra implements Runnable
{
    private Recurso recurso  ;
    private int TH ; 
    public  Thread thr   ;
    int numero ; 

    public Hebra( Recurso el_recurso, int tipo, int numero )
  {
      recurso = el_recurso ;
      TH = tipo ;
      this.numero = numero ; 
      thr = new Thread(this, "hebra " + Integer.toString(numero)) ; 
  }

  public void run()
  {
      while(true){
	  recurso.acceso(TH, thr.getName()) ;
	  aux.dormir_max( 2000 + 25 * numero ) ;
	  recurso.fin_acceso(TH, thr.getName()) ;
	  aux.dormir_max( 3000 - 43 * numero ) ; 
      }
  }
}

class ControlRecurso
{
  public static void main( String[] args )
  {
    if ( args.length != 2 )
    {
      System.err.println("ARGUMENTOS INCORRECTOS: (1) Hebras tipo 1, (2) Hebras tipo 2");
      return ;
    }

    Recurso el_recurso = new Recurso(); 

    int ntipo[] = new int[2] ;
    ntipo[0] = Integer.parseInt(args[0]) ;
    ntipo[1] = Integer.parseInt(args[1]) ;

    int n_hebras = ntipo[0] + ntipo[1] ; 
    
    Hebra [] hebras = new Hebra[n_hebras] ;

    int i = 0 ;
    
    for( ; i < ntipo[0] ; i++)
	hebras[i] = new Hebra( el_recurso, 0, i) ; 
    for( int j = 0 ; j < ntipo[1] ; j++, i++)
	hebras[i] = new Hebra( el_recurso, 1, i) ;

    for( i = 0 ; i < n_hebras ; i++)
	hebras[i].thr.start() ;
  }
}
